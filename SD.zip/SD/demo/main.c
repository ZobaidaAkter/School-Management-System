#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ================= STRUCTURES ================= */
struct Student {
    int id;
    char name[50];
    int className;
    int marks[3];
    int attendance;
};

struct Teacher {
    int id;
    char name[50];
    int classAssigned;
    int attendance;
};

struct Subject {
    int id;
    char name[30];
    int classLevel;
};

/* ================= GLOBAL VARIABLES ================= */
struct Student students[50];
struct Teacher teachers[20];
struct Subject subjects[3];

int studentCount = 0, teacherCount = 0, subjectCount = 0;
int currentUserRole = 0; // 1: Admin, 2: Teacher

/* ================= 7. USER LOGIN SYSTEM ================= */
int login() {
    char user[20], pass[20];
    printf("\n--- Login System ---\n");
    printf("Username: ");
    scanf("%s", user);
    printf("Password: ");
    scanf("%s", pass);

    if (strcmp(user, "group1") == 0 && strcmp(pass, "group1mzss") == 0) {
        currentUserRole = 1;
        return 1;
    } else if (strcmp(user, "teacher") == 0 && strcmp(pass, "t123") == 0) {
        currentUserRole = 2;
        return 1;
    }
    return 0;
}

/* ================= 1. STUDENT MANAGEMENT ================= */
void manageStudents() {
    int ch, id;
    char searchName[50];

    printf("\nStudent Management:\n");
    printf("1.Add\n2.Edit\n3.Delete\n4.Search\n5.Display\nChoice: ");
    scanf("%d", &ch);

    if(ch == 1) {
        printf("ID: "); scanf("%d", &students[studentCount].id);
        printf("Name: "); scanf(" %[^\n]", students[studentCount].name);
        printf("Class: "); scanf("%d", &students[studentCount].className);
        students[studentCount].attendance = 0;
        studentCount++;
        printf("Student Added!\n");
    }
    else if(ch == 2) {
        printf("Enter ID to Edit: "); scanf("%d", &id);
        for(int i=0;i<studentCount;i++)
            if(students[i].id == id) {
                printf("New Name: ");
                scanf(" %[^\n]", students[i].name);
                printf("Updated!\n");
                return;
            }
    }
    else if(ch == 3) {
        printf("ID to Delete: "); scanf("%d", &id);
        for(int i=0;i<studentCount;i++)
            if(students[i].id == id) {
                for(int j=i;j<studentCount-1;j++)
                    students[j] = students[j+1];
                studentCount--;
                printf("Deleted!\n");
                return;
            }
    }
    else if(ch == 4) {
        printf("Search by Name: ");
        scanf(" %[^\n]", searchName);
        for(int i=0;i<studentCount;i++)
            if(strstr(students[i].name, searchName))
                printf("%d %s Class %d\n",
                    students[i].id,
                    students[i].name,
                    students[i].className);
    }
    else if(ch == 5) {
        printf("\nID\tName\t\tClass\n");
        for(int i=0;i<studentCount;i++)
            printf("%d\t%-15s\t%d\n",
                students[i].id,
                students[i].name,
                students[i].className);
    }
}

/* ================= 2. TEACHER MANAGEMENT ================= */
void manageTeachers() {
    if(currentUserRole != 1) {
        printf("Admin only!\n");
        return;
    }

    int ch, id;
    printf("\nTeacher Management:\n");
    printf("1.Add\n2.Edit\n3.Delete\n4.Search\n5.Display\nChoice: ");
    scanf("%d", &ch);

    if(ch == 1) {
        printf("ID: "); scanf("%d", &teachers[teacherCount].id);
        printf("Name: "); scanf(" %[^\n]", teachers[teacherCount].name);
        printf("Class Assigned: ");
        scanf("%d", &teachers[teacherCount].classAssigned);
        teacherCount++;
    }
    else if(ch == 2) {
        printf("ID to Edit: "); scanf("%d", &id);
        for(int i=0;i<teacherCount;i++)
            if(teachers[i].id == id) {
                printf("New Name: ");
                scanf(" %[^\n]", teachers[i].name);
                printf("Updated!\n");
                return;
            }
    }
    else if(ch == 3) {
        printf("ID to Delete: "); scanf("%d", &id);
        for(int i=0;i<teacherCount;i++)
            if(teachers[i].id == id) {
                for(int j=i;j<teacherCount-1;j++)
                    teachers[j] = teachers[j+1];
                teacherCount--;
                printf("Deleted!\n");
                return;
            }
    }
    else if(ch == 4) {
        printf("Search ID: "); scanf("%d", &id);
        for(int i=0;i<teacherCount;i++)
            if(teachers[i].id == id)
                printf("%d %s Class %d\n",
                    teachers[i].id,
                    teachers[i].name,
                    teachers[i].classAssigned);
    }
    else if(ch == 5) {
        printf("\nID\tTeacher Name\tClass\n");
        for(int i=0;i<teacherCount;i++)
            printf("%d\t%-15s\t%d\n",
                teachers[i].id,
                teachers[i].name,
                teachers[i].classAssigned);
    }
}

/* ================= 4. ATTENDANCE MANAGEMENT [cite: 60-65] ================= */
void markAttendance() {
    int type, id, found = 0;
    printf("1.Student \n2.Teacher \nChoice: ");
    scanf("%d", &type);
    printf("Enter ID: ");
    scanf("%d", &id);

    if(type == 1) { // Student Attendance [cite: 63]
        for(int i = 0; i < studentCount; i++) {
            if(students[i].id == id) {
                students[i].attendance = 1;
                printf("Attendance Done! Student Name: %s, ID: %d is now Present.\n", students[i].name, students[i].id);
                found = 1;
                break;
            }
        }
    } else { // Teacher attendance[cite: 64]
        for(int i = 0; i < teacherCount; i++) {
            if(teachers[i].id == id) {
                teachers[i].attendance = 1;
                printf("Attendance Done! Teacher Name: %s, ID: %d is now Present.\n", teachers[i].name, teachers[i].id);
                found = 1;
                break;
            }
        }
    }

    if(!found) {
        printf("Error: ID %d not found in the system!\n", id);
    }
}


/* ================= 5. RESULT MANAGEMENT ================= */
void manageResults() {
    int id;
    printf("Student ID: ");
    scanf("%d", &id);

    for(int i=0;i<studentCount;i++)
        if(students[i].id == id) {
            for(int j=0;j<subjectCount;j++) {
                printf("%s: ", subjects[j].name);
                scanf("%d", &students[i].marks[j]);
            }
            printf("Marks Updated!\n");
            return;
        }
}

/* ================= MARKSHEET ================= */
void showMarksheet() {
    int id;
    printf("Enter ID: ");
    scanf("%d", &id);

    for(int i=0;i<studentCount;i++)
        if(students[i].id == id) {
            int total = 0;
            printf("\n--- Marksheet ---\n");
            for(int j=0;j<subjectCount;j++) {
                printf("%s: %d\n",
                    subjects[j].name,
                    students[i].marks[j]);
                total += students[i].marks[j];
            }
            float avg = (float)total/subjectCount;
            printf("Average: %.2f | Grade: %c\n",
                avg,
                avg>=80?'A':avg>=60?'B':avg>=40?'C':'F');
            return;
        }
}

/* ================= 8. REPORT GENERATION ================= */
void generateReports() {
    printf("\n--- Student Report ---\n");
    for(int i=0;i<studentCount;i++)
        printf("%d %s Class %d\n",
            students[i].id,
            students[i].name,
            students[i].className);

    printf("\n--- Teacher Report ---\n");
    for(int i=0;i<teacherCount;i++)
        printf("%d %s Class %d\n",
            teachers[i].id,
            teachers[i].name,
            teachers[i].classAssigned);

    printf("\n--- Attendance Report ---\n");
    for(int i=0;i<studentCount;i++)
        if(students[i].attendance)
            printf("Present: %s\n", students[i].name);
}

/* ================= MAIN FUNCTION ================= */
int main() {
    strcpy(subjects[0].name, "Mathematics");
    strcpy(subjects[1].name, "English");
    strcpy(subjects[2].name, "Physics");
    subjectCount = 3;

    students[0] = (struct Student){101, "Menhajul Islam", 10, {85, 80, 90}, 0};
    students[1] = (struct Student){102, "Zobaida Akter", 10, {87, 95, 82}, 0};
    students[2] = (struct Student){103, "Shotabdi ", 10, {75, 85, 75}, 0};
    students[3] = (struct Student){104, "Al-Jerin Islam", 10, {70, 75, 85}, 0};
    studentCount = 4;

    teachers[0] = (struct Teacher){201, "Jannat Rosul Nisha", 10, 0};
    teachers[1] = (struct Teacher){202, "Md. Anik Hasan", 10, 0};
    teachers[2] = (struct Teacher){203, "Md. Yousuf Ali", 10, 0};
    teachers[3] = (struct Teacher){204, "Nashrullah Naum", 10, 0};
    teachers[4] = (struct Teacher){205, "Tousif Hasan Lavlu", 10, 0};
    teacherCount = 5;


    if(!login()) {
        printf("Login Failed!\n");
        return 0;
    }

    int choice;
    while(1) {
        printf("\n===== MENU (%s) =====\n",
            (currentUserRole==1)?"Admin":"Teacher");
        printf("1.Students\n2.Teachers\n3.Attendance\n4.Add Marks\n5.Marksheet\n6.Reports\n0.Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1: manageStudents(); break;
            case 2: manageTeachers(); break;
            case 3: markAttendance(); break;
            case 4: manageResults(); break;
            case 5: showMarksheet(); break;
            case 6: generateReports(); break;
            case 0: exit(0);
            default: printf("Invalid choice!\n");
        }
    }
    return 0;
}
